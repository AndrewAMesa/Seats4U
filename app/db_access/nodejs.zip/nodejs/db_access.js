module.exports = {
    // credentials to the DB are here. HIDDEN and not exposed outside
    // NOTE: YOU SHOULD REPLACE WITH YOUR OWN NATURALLY. These are the ones
    // that you set up 
    config : {
     "host"     : "bunjiltest.cqimjmwgep0x.us-east-1.rds.amazonaws.com",
     "user"     : "bunjil",
     "password" : "Te2kNgICS0b0I8F0O6a1",
     "database" : "seats4U"
   }
 }
 