const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access');

exports.handler = async (event) => {
    // Get credentials from the db_access layer (loaded separately via AWS console)
    var pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database
    });

    let errorMessage = "error";

    console.log(event.name);

    let alreadyExists = undefined
    if(event.type == 0){
    // Validates if that venue name already exists
      let venueNameExists = (name) => {
          return new Promise((resolve, reject) => {
              pool.query("SELECT * FROM Venues WHERE venueName=?", [name], (error, rows) => {
                  if (error) {
                      return reject(error);
                  }
                  console.log(rows);
                  if ((rows) && (rows.length >= 1)) {
                      return resolve(true);
                  } else {
                    errorMessage = "Venue name does not exist";
                    return resolve(false);
                  }
              });
          });
      };
      alreadyExists = await venueNameExists(event.name);
    } else {
      let showNameExists = (name) => {
          return new Promise((resolve, reject) => {
              pool.query("SELECT * FROM Shows WHERE showName=?", [name], (error, rows) => {
                  if (error) {
                      return reject(error);
                  }
                  console.log(rows);
                  if ((rows) && (rows.length >= 1)) {
                      
                      return resolve(true);
                  } else {
                      errorMessage = "Show name does not exist";
                      return resolve(false);
                  }
              });
          });
      };
      alreadyExists = await showNameExists(event.name);
    }

    let response = undefined;
    console.log("checking");
    let allShows = undefined;
    if (alreadyExists) {
        if (event.type == 0) {
          let ListShowsVenue = (name) => 
          {
              return new Promise((resolve, reject) => 
              {
                  pool.query("SELECT showName, showDate, showTime, defualtPrice FROM Shows WHERE venueName=? AND isActive=1 ", [name], (error, rows) => 
                  {
                      if (error) { return reject(error); }
                      return resolve(rows);
                  })
              })
          }
          
          allShows = await ListShowsVenue()
        } else {
          let ListShowsShow = (name) => 
          {
              return new Promise((resolve, reject) => 
              {
                  pool.query("SELECT showName, showDate, showTime, defualtPrice FROM Shows WHERE showName=? AND isActive=1 ", [name], (error, rows) => 
                  {
                      if (error) { return reject(error); }
                      return resolve(rows);
                  })
              })
          }
          
          allShows = await ListShowsShow()
        }
        response = {
            statusCode: 200,
            token: JSON.stringify(allShows),
        };
    } else {
        // If the venue name already exists, return an error response
        response = {
            statusCode: 400,
            error: JSON.stringify(errorMessage)
        };
    }

    pool.end();   // Done with DB
    return response;
};